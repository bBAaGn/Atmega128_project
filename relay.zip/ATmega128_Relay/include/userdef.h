#ifndef USERDEF_H_
#define USERDEF_H_

#ifndef F_CPU
#define F_CPU 8000000UL
#endif

#include <avr/io.h>
#include <util/delay.h>

// Địa chỉ phần cứng chọn chip CS10 điều khiển Relay qua bus EMI (chuẩn bài kiểm tra)
#define RELAY_ADDR _SFR_MEM8(0x800A)

// Cấu trúc Bit-field và Union quản lý 8 Relay theo bài giảng P1.4
struct bits {
    unsigned char b0 : 1; // Relay 1
    unsigned char b1 : 1; // Relay 2
    unsigned char b2 : 1; // Relay 3
    unsigned char b3 : 1; // Relay 4
    unsigned char b4 : 1; // Relay 5
    unsigned char b5 : 1; // Relay 6
    unsigned char b6 : 1; // Relay 7
    unsigned char b7 : 1; // Relay 8
};

union byte_bits {
    unsigned char byte;
    struct bits b;
};

// Biến trạng thái toàn cục
extern union byte_bits relays;

// Macro đẩy trạng thái byte ra phần cứng Relay
#define RELAY_ACTIVATION (RELAY_ADDR = relays.byte)

// Khai báo hàm điều khiển
void execute_relay_action(uint8_t option);

#endif /* USERDEF_H_ */
