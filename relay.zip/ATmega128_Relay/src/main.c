#include "userdef.h"

// Khởi tạo biến quản lý 8 relay
union byte_bits relays;

// Hàm thực thi các tác vụ relay theo menu bài kiểm tra
void execute_relay_action(uint8_t option) {
    switch (option) {
        case 0: // ON ALL RELAYs
            relays.byte = 0xFF; 
            break;
        case 1: // OFF ALL RELAYs
            relays.byte = 0x00; 
            break;
        case 2: // ON RELAY 1 3 5 7 (xen kẽ)
            relays.byte = 0x55; 
            break;
        case 3: // ON RELAY 2 4 6 8 (xen kẽ)
            relays.byte = 0xAA; 
            break;
        default: 
            break;
    }
    RELAY_ACTIVATION; // Đẩy dữ liệu ra chốt 74HC573
}

int main(void) {
    // 1. Kích hoạt giao diện bộ nhớ ngoài EMI trên ATmega128 (SRE = 1)
    MCUCR |= (1 << SRE);
    XMCRA = 0;

    // 2. Khởi tạo: Tắt toàn bộ relay
    execute_relay_action(1);
    _delay_ms(1000);

    while (1) {
        // Chế độ 1: Bật Relay 1, 3, 5, 7 (0x55)
        execute_relay_action(2);
        _delay_ms(1500);

        // Chế độ 2: Bật Relay 2, 4, 6, 8 (0xAA)
        execute_relay_action(3);
        _delay_ms(1500);

        // Chế độ 3: Bật tất cả 8 Relay (0xFF)
        execute_relay_action(0);
        _delay_ms(1500);

        // Chế độ 4: Tắt toàn bộ 8 Relay (0x00)
        execute_relay_action(1);
        _delay_ms(1500);

        // Chế độ 5: Điều khiển bit riêng lẻ qua Struct (Bật Relay 1 và Relay 6)
        relays.byte = 0x00;
        relays.b.b0 = 1; // Kích Relay 1
        relays.b.b5 = 1; // Kích Relay 6
        RELAY_ACTIVATION;
        _delay_ms(2000);
    }

    return 0;
}
