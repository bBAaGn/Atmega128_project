# HƯỚNG DẪN SỬ DỤNG GÓI DỰ ÁN RELAY (P1.4) - ATmega128

## 1. Cấu trúc thư mục gói nạp
```text
ATmega128_Relay/
├── ATmega128_Relay.hex       (File mã máy đã biên dịch sẵn nạp trực tiếp vào Proteus)
├── HUONG_DAN.md              (Hướng dẫn chi tiết này)
├── include/
│   └── userdef.h             (Khai báo Struct/Union và địa chỉ RELAY_ADDR 0x800A)
└── src/
    └── main.c                (Mã nguồn C chương trình điều khiển Relay)
```

## 2. Nạp trực tiếp vào mô phỏng Proteus (Không cần build lại)
1. Mở file mô phỏng Proteus chứa sơ đồ mạch điều khiển Relay ATmega128.
2. Nhấp đúp chuột trái (Double-click) vào con vi điều khiển **ATMEGA128**.
3. Tại ô **Program File**: Nhấn vào biểu tượng thư mục màu vàng $\square$, trỏ đến file **`ATmega128_Relay.hex`** trong gói này.
4. Kiểm tra ô **Advanced Properties** / **Clock Frequency**: Đảm bảo đặt là **`8MHz`**.
5. Nhấn **OK**, sau đó bấm nút **Play (Run Simulation)** ở góc dưới Proteus để xem 8 relay tự động đóng cắt theo chu kỳ.

## 3. Sử dụng trong VS Code / PlatformIO
1. Sao chép nội dung `include/userdef.h` vào thư mục `include/` của project bạn trong VS Code.
2. Sao chép nội dung `src/main.c` vào thư mục `src/` của project bạn.
3. Nhấn **Build** (biểu tượng $\checkmark$) để tự tạo file `.hex` mới bất kỳ lúc nào bạn chỉnh sửa.
