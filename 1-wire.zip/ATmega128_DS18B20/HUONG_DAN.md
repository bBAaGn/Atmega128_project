# ATmega128 - DS18B20 - 4 LED 7 đoạn qua EMI

Code dùng AVR-GCC, vi điều khiển ATmega128 chạy 8 MHz. Thuật toán theo Document 59.pdf; địa chỉ LED đã sửa theo kết nối thực tế trong tonghopnhung.pdsprj. Các dòng xử lý có chú thích tiếng Việt ngay bên phải.

## Các file

- `src/main.c`: giao tiếp 1-Wire, đọc nhiệt độ và xuất LED.
- `include/userdef.h`: ánh xạ địa chỉ 4 chốt LED.
- `ATmega128_DS18B20.hex`: chương trình đã biên dịch, dùng để nạp vào Proteus.

## Cách chạy trong Proteus

1. Mở thuộc tính ATMEGA128, chọn file HEX tại mục **Program File**.
2. Đặt **Clock Frequency = 8MHz**. F_CPU trong code chỉ phục vụ tính thời gian trễ, không tự đổi xung clock của chip.
3. DS18B20: DQ nối PB0 (chân 10), kéo lên +5V bằng điện trở 4.7 kOhm; VDD nối +5V và GND nối mass.
4. Dùng 4 LED anode chung, các đoạn a..g,dp tương ứng Q0..Q7; chân OE của các chốt nối GND.
5. Địa chỉ đúng với mạch được gửi: 0x8007 -> CS7 -> U14/hàng nghìn, 0x8006 -> CS6 -> U16/hàng trăm, 0x8005 -> CS5 -> U18/hàng chục, 0x8004 -> CS4 -> U20/hàng đơn vị.
6. Chạy mô phỏng. Lúc mới bật, LED hiện `----`; sau lần đo đầu tiên sẽ hiện nhiệt độ, ví dụ 25 độ C -> `0025`. Bấm (+)/(-) trên DS18B20 để thay đổi nhiệt độ.

Code dùng chế độ ATmega128 thông thường. Nếu mô hình chip có tùy chọn fuse **M103C**, cần tắt chế độ tương thích ATmega103 khi dùng chương trình này.

## Giải thích logic tổng thể

1. Bật bộ nhớ ngoài bằng `MCUCR |= 0x80`, đặt `XMCRA = 0`, `XMCRB = 0`.
2. Nhả PB0, để điện trở ngoài kéo đường DQ lên cao. Master chỉ kéo thấp hoặc nhả bus.
3. Reset cảm biến: kéo thấp 480 us, nhả 60 us, kiểm tra presence ở mức thấp, chờ thêm 420 us.
4. Gửi `0xCC` (Skip ROM) rồi `0x44` (Convert T), theo thứ tự bit thấp trước. Chỉ nối một DS18B20 trên bus khi dùng Skip ROM để đọc nhiệt độ.
5. Chờ 750 lần, mỗi lần xuất lại 4 LED rồi delay 1 ms. Tổng thời gian thực sẽ dài hơn 750 ms một chút do thời gian xử lý và ghi LED.
6. Reset lần nữa, gửi `0xCC`, `0xBE`, đọc byte thấp rồi byte cao.
7. Ghép `raw = (int16_t)(((uint16_t)high << 8) | low)` rồi lấy `temp = raw >> 4` đúng phép tính trong đề.
8. Tách từng chữ số và ghi bảng mã anode chung vào các địa chỉ LED. Đo lặp lại liên tục.

Vì mỗi LED có một chốt 74HC573 riêng, dữ liệu vẫn được giữ giữa các lần ghi; không cần bật/tắt chọn từng LED như mạch quét dùng chung bus đoạn. Chương trình vẫn ghi lại LED trong thời gian chờ theo yêu cầu đề.

## Ví dụ hiển thị

| Nhiệt độ nguyên | Bốn LED từ trái sang phải |
| --- | --- |
| 0 độ C | 0000 |
| 25 độ C | 0025 |
| 100 độ C | 0100 |
| -5 độ C | -005 |
| Không nhận được presence | ---- |

Đề yêu cầu nhiệt độ nguyên nên không hiển thị phần thập phân. Với AVR-GCC, dịch phải số âm có dấu làm tròn xuống: ví dụ -0.5 độ C hiển thị -001, theo đúng `raw >> 4` trong đề. Đây khác với phép chia số nguyên `/ 16` vốn cắt về 0 khi số âm.

`ReadTemp()` trả 1 khi có presence ở cả hai lần reset và đã đọc hai byte; trả 0 khi thiếu presence. Code chỉ đọc hai byte theo đề, chưa đọc CRC để phát hiện lỗi truyền dữ liệu.

## Biên dịch lại bằng AVR-GCC

Thêm thư mục `bin` của AVR-GCC vào PATH, mở terminal tại thư mục chứa hướng dẫn này:

```powershell
avr-gcc -mmcu=atmega128 -DF_CPU=8000000UL -Os -std=gnu99 -Wall -Wextra -Werror -I include src/main.c -o ATmega128_DS18B20.elf
avr-objcopy -O ihex -R .eeprom ATmega128_DS18B20.elf ATmega128_DS18B20.hex
```

Cần giữ tùy chọn tối ưu `-Os` để các hàm `_delay_us()` có thời gian đúng. Code này dùng thư viện AVR-GCC (`avr/io.h`, `util/delay.h`), không dùng cú pháp của CodeVisionAVR hay CCS C cho PIC.

## Kiểm tra và giới hạn

Đã biên dịch cho `-mmcu=atmega128` bằng AVR-GCC 7.3.0, dùng `-Wall -Wextra -Werror`, không có lỗi/cảnh báo. Đã kiểm tra mã máy ghi ra đủ 4 địa chỉ 0x8004..0x8007, phép dịch phải giữ dấu và thời điểm lấy mẫu khe đọc tại 8 MHz. File HEX đã kiểm tra checksum từng bản ghi.

Đã đọc kết nối trong file dự án: U2 chốt D0..D7 thành A0..A7 bằng ALE; U3 (74154) nhận A0..A3, E1 nối A4, E2 nối GND. Khi A4 = 0, bốn bit A0..A3 chọn ngõ ra CS0..CS15. U14/U16/U18/U20 nhận tín hiệu LE từ các NOR kết hợp WR với CS7/CS6/CS5/CS4. Do đó phải dùng địa chỉ kết thúc bằng 7/6/5/4, thay vì 0/1/2/3 như PDF.

File dự án ban đầu lưu Program File là `C:\Users\Windows\Documents\PlatformIO\Projects\DS18B20_P1_8\.pio\build\ATmega128\firmware.hex`, thuộc đường dẫn máy khác. Cần chọn lại HEX mới tại Program File của U1. Clock trong file đã đặt 8MHz.

Chưa xác nhận LED hiển thị và nút tăng/giảm bằng mô phỏng trực tiếp: công cụ điều khiển đọc được tên cửa sổ/menu Proteus nhưng chụp ảnh cửa sổ bị timeout, nên không thể xem kết quả trên canvas. Kiểm tra kết nối tĩnh và biên dịch thành công không thay thế kiểm chứng mô phỏng.

LED cập nhật sau mỗi lần chuyển đổi và đọc dữ liệu, khoảng một giây tùy thời gian xử lý; không thay đổi ngay tại thời điểm bấm nút. Thời gian chuyển đổi tối đa ở độ phân giải 12 bit là 750 ms theo [datasheet DS18B20](https://www.analog.com/media/en/technical-documentation/data-sheets/ds18b20.pdf). Tham khảo giao diện EMI tại [datasheet ATmega128](https://www.microchip.com/content/dam/mchp/documents/OTH/ProductDocuments/DataSheets/doc2467.pdf).
