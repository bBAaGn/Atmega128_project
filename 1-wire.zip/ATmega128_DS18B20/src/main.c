#ifdef F_CPU
#undef F_CPU                                                      // Bỏ tần số do cấu hình build truyền vào nếu có.
#endif
#define F_CPU 8000000UL                                            // Tần số thực tế của ATmega128: 8 MHz.

#include <avr/io.h>                                                // Khai báo DDRB, PORTB, PINB, MCUCR, XMCRA...
#include <util/delay.h>                                            // Hàm tạo trễ theo F_CPU.
#include <stdint.h>                                                // Kiểu uint8_t, uint16_t, int16_t.
#include "userdef.h"                                               // Ánh xạ 4 LED vào bộ nhớ ngoài.

const uint8_t SegCode[10] =                                        // Bảng mã LED 7 đoạn anode chung: mức 0 làm sáng đoạn.
{
    0xC0, 0xF9, 0xA4, 0xB0, 0x99,                                // Mã các chữ số 0, 1, 2, 3, 4.
    0x92, 0x82, 0xF8, 0x80, 0x90                                 // Mã các chữ số 5, 6, 7, 8, 9.
};

void OW_Low(void)
{
    DDRB |= (1 << PB0);                                           // PB0 là ngõ ra để master kéo bus xuống thấp.
    PORTB &= ~(1 << PB0);                                         // Xuất mức 0; không chủ động xuất mức 1 trên bus.
}

void OW_Free(void)
{
    DDRB &= ~(1 << PB0);                                          // PB0 trở thành ngõ vào, nhả bus ở trạng thái High-Z.
    PORTB &= ~(1 << PB0);                                         // Tắt pull-up nội; dùng điện trở kéo ngoài 4.7 kOhm.
}

uint8_t OW_Reset(void)
{
    uint8_t presence;

    OW_Low();                                                    // Bắt đầu xung reset của master.
    _delay_us(480);                                               // Giữ bus ở mức thấp 480 us.
    OW_Free();                                                   // Nhả bus cho cảm biến trả lời.
    _delay_us(60);                                                // Chờ 60 us trước khi kiểm tra presence.
    presence = ((PINB & (1 << PB0)) == 0);                         // Cảm biến kéo mức 0: trả về 1, nghĩa là có cảm biến.
    _delay_us(420);                                               // Chờ kết thúc khung reset.

    return presence;
}

void OW_WriteByte(uint8_t data)
{
    uint8_t i;

    for (i = 0; i < 8; i++)                                      // Gửi đủ 8 bit, bit thấp nhất trước.
    {
        OW_Low();                                                // Bắt đầu khe ghi bằng mức thấp.
        _delay_us(2);                                             // Kéo thấp ban đầu 2 us.

        if (data & 0x01)                                         // Bit cần gửi là 1.
        {
            OW_Free();                                           // Nhả ngay để điện trở kéo bus lên mức cao.
            _delay_us(60);                                       // Chờ phần còn lại của khe ghi.
        }
        else                                                     // Bit cần gửi là 0.
        {
            _delay_us(60);                                       // Tiếp tục giữ bus thấp 60 us.
            OW_Free();                                           // Kết thúc bit 0 bằng cách nhả bus.
        }

        _delay_us(5);                                            // Nghỉ 5 us giữa hai bit.
        data >>= 1;                                              // Đưa bit kế tiếp về vị trí bit 0.
    }
}

uint8_t OW_ReadByte(void)
{
    uint8_t i;
    uint8_t data = 0;                                             // Xóa byte trước khi ghép từng bit đọc được.

    for (i = 0; i < 8; i++)                                      // Đọc 8 bit theo thứ tự LSB trước.
    {
        OW_Low();                                                // Master bắt đầu khe đọc.
        _delay_us(2);                                             // Kéo bus xuống thấp 2 us.
        OW_Free();                                               // Nhả bus để cảm biến đưa bit ra đường DQ.
        _delay_us(8);                                             // Chờ 8 us; dành thêm biên thời gian cho lệnh gọi hàm/lấy mẫu.

        if (PINB & (1 << PB0))                                   // Nếu mức bus là 1 thì đặt bit tương ứng trong data.
        {
            data |= (uint8_t)(1U << i);
        }

        _delay_us(50);                                           // Chờ hết khe đọc trước khi chuyển sang bit tiếp theo.
    }

    return data;                                                 // Trả về byte đã ghép đủ 8 bit.
}

void DisplayError(void)
{
    LED7D1 = 0xBF;                                                // 0xBF chỉ bật đoạn g: dấu gạch ngang.
    LED7D2 = 0xBF;
    LED7D3 = 0xBF;
    LED7D4 = 0xBF;                                                // Hiển thị ---- khi chưa có dữ liệu hoặc thiếu cảm biến.
}

void DisplayTemp(int16_t temp)
{
    uint16_t value;

    if (temp < 0)                                                // Xử lý nhiệt độ âm trước khi tra bảng mã.
    {
        value = (uint16_t)(-temp);                                // Lấy độ lớn để chỉ số SegCode luôn từ 0 đến 9.
        LED7D4 = 0xBF;                                            // Đặt dấu âm ở LED ngoài cùng bên trái.
    }
    else
    {
        value = (uint16_t)temp;
        LED7D4 = SegCode[(value / 1000) % 10];                    // Hàng nghìn theo công thức trong đề.
    }

    LED7D3 = SegCode[(value / 100) % 10];                          // Hàng trăm.
    LED7D2 = SegCode[(value / 10) % 10];                           // Hàng chục.
    LED7D1 = SegCode[value % 10];                                 // Hàng đơn vị: ví dụ 25 độ C hiển thị 0025.
}

void WaitConversion(int16_t last_temp, uint8_t valid)
{
    uint16_t i;

    for (i = 0; i < 750; i++)                                    // Chờ ít nhất 750 ms để hoàn thành chuyển đổi 12 bit.
    {
        if (valid)
        {
            DisplayTemp(last_temp);                              // Tiếp tục ghi nhiệt độ lần đo trước ra các chốt LED.
        }
        else
        {
            DisplayError();                                      // Chưa có kết quả: duy trì ---- trong lúc chờ.
        }

        _delay_ms(1);                                            // Chia thời gian chờ thành từng khoảng 1 ms.
    }
}

uint8_t ReadTemp(int16_t *temp, uint8_t valid)
{
    uint8_t low;
    uint8_t high;
    int16_t raw;

    if (!OW_Reset())                                             // Không có presence thì bỏ lần đo này.
    {
        return 0;
    }

    OW_WriteByte(0xCC);                                          // Skip ROM: bus chỉ nối một DS18B20.
    OW_WriteByte(0x44);                                          // Convert T: bắt đầu đo/chuyển đổi nhiệt độ.
    OW_Free();                                                   // Nhả bus trong thời gian cảm biến chuyển đổi.
    WaitConversion(*temp, valid);                                // Chờ 750 ms và duy trì hiển thị LED.

    if (!OW_Reset())                                             // Kiểm tra cảm biến trước khi đọc kết quả.
    {
        return 0;
    }

    OW_WriteByte(0xCC);                                          // Skip ROM lần thứ hai.
    OW_WriteByte(0xBE);                                          // Read Scratchpad: đọc bộ nhớ kết quả.
    low = OW_ReadByte();                                         // Byte 0: phần thấp của nhiệt độ.
    high = OW_ReadByte();                                        // Byte 1: phần cao, bao gồm bit dấu.
    OW_Free();                                                   // Kết thúc đọc; lần đo kế tiếp bắt đầu bằng reset.

    raw = (int16_t)(((uint16_t)high << 8) | low);                  // Ghép hai byte thành số 16 bit có dấu.
    *temp = raw >> 4;                                            // Lấy nhiệt độ nguyên đúng phép dịch 4 bit trong đề.

    return 1;                                                    // Đã nhận được hai byte nhiệt độ.
}

int main(void)
{
    int16_t temp = 0;                                            // Biến chứa nhiệt độ gần nhất.
    uint8_t valid = 0;                                           // Lúc khởi động chưa có kết quả đo.

    MCUCR |= 0x80;                                               // Đặt SRE = 1 để bật giao diện bộ nhớ ngoài EMI.
    XMCRA = 0;                                                   // Không thêm wait state, theo cấu hình của đề.
    XMCRB = 0;                                                   // Dùng đầy đủ các đường địa chỉ PC0..PC7.
    OW_Free();                                                   // Bus 1-Wire ban đầu ở trạng thái nhả, pull-up nội tắt.
    DisplayError();                                              // Hiển thị ---- cho đến lần đo đầu tiên.

    while (1)
    {
        valid = ReadTemp(&temp, valid);                          // Đo lại liên tục để theo thay đổi nhiệt độ trong Proteus.

        if (valid)
        {
            DisplayTemp(temp);                                   // Hiển thị ngay kết quả vừa đọc được.
        }
        else
        {
            DisplayError();                                      // Thiếu cảm biến: tránh hiển thị nhầm nhiệt độ 0000.
            _delay_ms(100);                                      // Chờ ngắn trước khi kiểm tra kết nối lại.
        }
    }
}
