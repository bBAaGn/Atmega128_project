#ifndef USERDEF_H_
#define USERDEF_H_

#include <avr/io.h>                                                // Thanh ghi của vi điều khiển AVR.

#define LED7D4 (*(volatile unsigned char *)(0x8007))                // CS7 -> NOR U15 -> U14: LED hàng nghìn.
#define LED7D3 (*(volatile unsigned char *)(0x8006))                // CS6 -> NOR U17 -> U16: LED hàng trăm.
#define LED7D2 (*(volatile unsigned char *)(0x8005))                // CS5 -> NOR U19 -> U18: LED hàng chục.
#define LED7D1 (*(volatile unsigned char *)(0x8004))                // CS4 -> NOR U21 -> U20: LED hàng đơn vị.

#endif
