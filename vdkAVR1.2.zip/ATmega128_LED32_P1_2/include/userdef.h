#ifndef USERDEF_H_
#define USERDEF_H_

#ifndef F_CPU
#define F_CPU 8000000UL
#endif

#include <avr/io.h>
#include <util/delay.h>

// -------------------------------------------------------------
// ĐỊNH NGHĨA ĐỊA CHỈ PHẦN CỨNG 32 LED ĐƠN QUA BUS EMI (P1.2)
// Khớp 100% với sơ đồ giải mã Proteus và file kiemtra.h
// -------------------------------------------------------------
#define LED0 (*(volatile uint8_t *)(0x8000)) // LED_0_7   (Byte 0 - Thấp nhất)
#define LED1 (*(volatile uint8_t *)(0x8001)) // LED_8_15  (Byte 1)
#define LED2 (*(volatile uint8_t *)(0x8002)) // LED_16_23 (Byte 2)
#define LED3 (*(volatile uint8_t *)(0x8003)) // LED_24_31 (Byte 3 - Cao nhất)

// Khai báo nguyên mẫu hàm hiển thị 32 LED
void led_display(unsigned long led_data);

#endif /* USERDEF_H_ */
