#include "userdef.h"

/**
 * Hàm phân tách biến 32-bit thành 4 byte xuất ra 4 IC chốt 74HC573
 * Phương pháp theo bài giảng P1.2 của Thầy Trương Ngọc Sơn
 */
void led_display(unsigned long led_data) {
    LED0 = (uint8_t)(led_data & 0x000000FF);
    LED1 = (uint8_t)((led_data >> 8) & 0x000000FF);
    LED2 = (uint8_t)((led_data >> 16) & 0x000000FF);
    LED3 = (uint8_t)((led_data >> 24) & 0x000000FF);
}

int main(void) {
    // 1. Kích hoạt giao diện bộ nhớ ngoài EMI trên ATmega128 (bit SRE trong MCUCR)
    MCUCR |= (1 << SRE);
    XMCRA = 0;

    // 2. Mẫu hiển thị 32-bit sáng xen kẽ chuẩn video bài giảng: 0xAA555555
    unsigned long led = 0xAA555555;

    while (1) {
        // Xuất giá trị 32-bit ra 32 LED đơn
        led_display(led);

        // Độ trễ 800ms để quan sát rõ từng bước dịch LED trong Proteus
        _delay_ms(800);

        // Hiệu ứng dịch xoay vòng bit (Rotate Left 32-bit)
        led = (led << 1) | (led >> 31);
    }

    return 0;
}
