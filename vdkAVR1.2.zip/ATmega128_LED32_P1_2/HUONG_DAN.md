# HƯỚNG DẪN SỬ DỤNG GÓI DỰ ÁN 32 LED ĐƠN (P1.2) - ATmega128

## 1. Cấu trúc thư mục gói nạp
```text
ATmega128_LED32_P1_2/
├── ATmega128_LED32.hex       (File HEX mã máy đã biên dịch sẵn - nạp thẳng vào Proteus)
├── HUONG_DAN.md              (Hướng dẫn chi tiết này)
├── include/
│   └── userdef.h             (Khai báo địa chỉ 4 khối chốt 0x8000 - 0x8003)
└── src/
    └── main.c                (Mã nguồn C chuẩn tách 32-bit với độ trễ 800ms)
```

## 2. Nạp trực tiếp vào mô phỏng Proteus (Không cần biên dịch lại)
1. Mở sơ đồ mạch mô phỏng Proteus.
2. Nhấp đúp chuột trái vào con vi điều khiển **ATMEGA128**.
3. Tại ô **Program File**: Nhấn biểu tượng duyệt file và chọn **`ATmega128_LED32.hex`** trong gói này.
4. Kiểm tra ô **Clock Frequency**: Đảm bảo đặt là **`8MHz`**.
5. Nhấn **OK**, sau đó bấm nút **Play (Run Simulation)** ở góc dưới Proteus.

## 3. Sử dụng trên VS Code / PlatformIO
1. Sao chép nội dung file `include/userdef.h` vào thư mục `include/` của project trên VS Code.
2. Sao chép nội dung file `src/main.c` vào thư mục `src/`.
3. Nhấn nút **Build (✓)** ở thanh dưới cùng VS Code để biên dịch lại bất cứ khi nào bạn muốn thay đổi hiệu ứng.
